import { Transaction, Summary, MonthlyData, CategoryBreakdown, FilterState, Insight } from '../types';
import { CATEGORY_COLORS } from '../data/mockData';

export function fmt(n: number): string {
  return '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

export function fmtSigned(n: number): string {
  return (n >= 0 ? '+' : '-') + '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });
}

export function formatDateShort(dateStr: string): string {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US', {
    month: 'short', day: 'numeric',
  });
}

export function getSummary(transactions: Transaction[]): Summary {
  const income   = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expenses = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  return {
    income,
    expenses,
    balance: income - expenses,
    savingsRate: income > 0 ? Math.round(((income - expenses) / income) * 100) : 0,
  };
}

export function getMonthlyData(transactions: Transaction[]): MonthlyData {
  const months: Record<string, { income: number; expenses: number }> = {};
  transactions.forEach(t => {
    const m = t.date.substring(0, 7);
    if (!months[m]) months[m] = { income: 0, expenses: 0 };
    if (t.type === 'income') months[m].income += t.amount;
    else months[m].expenses += t.amount;
  });
  const keys = Object.keys(months).sort();
  return {
    labels: keys.map(k => {
      const d = new Date(k + '-01');
      return d.toLocaleString('default', { month: 'short', year: '2-digit' });
    }),
    income:   keys.map(k => months[k].income),
    expenses: keys.map(k => months[k].expenses),
  };
}

export function getCategoryBreakdown(transactions: Transaction[]): CategoryBreakdown[] {
  const expCats: Record<string, number> = {};
  transactions.filter(t => t.type === 'expense').forEach(t => {
    expCats[t.cat] = (expCats[t.cat] || 0) + t.amount;
  });
  const total = Object.values(expCats).reduce((s, v) => s + v, 0);
  return Object.entries(expCats)
    .sort(([, a], [, b]) => (b || 0) - (a || 0))
    .map(([category, amount]) => ({
      category: category as any,
      amount: amount || 0,
      percentage: total > 0 ? Math.round(((amount || 0) / total) * 100) : 0,
    }));
}

export function getInsights(transactions: Transaction[]): Insight[] {
  const { income, expenses, savingsRate } = getSummary(transactions);
  const breakdown = getCategoryBreakdown(transactions);
  const topCat = breakdown[0];
  const incomeCount  = transactions.filter(t => t.type === 'income').length;
  const expenseCount = transactions.filter(t => t.type === 'expense').length;

  const insights: Insight[] = [];

  if (topCat) {
    insights.push({
      icon: '⚠',
      color: CATEGORY_COLORS[topCat.category] || '#f6a623',
      text: `Biggest expense: <strong>${topCat.category}</strong> at ${fmt(topCat.amount)} (${topCat.percentage}% of spending)`,
    });
  }

  insights.push({
    icon: '◎',
    color: savingsRate >= 20 ? '#22d68a' : '#f56565',
    text: `Savings rate: <strong>${savingsRate}%</strong> — ${savingsRate >= 20 ? 'healthy savings! Keep it up.' : 'consider reducing expenses to save more.'}`,
  });

  insights.push({
    icon: '◈',
    color: '#5b8df6',
    text: `${expenseCount} expense transactions across ${breakdown.length} categories vs ${incomeCount} income sources.`,
  });

  const net = income - expenses;
  insights.push({
    icon: net >= 0 ? '↑' : '↓',
    color: net >= 0 ? '#22d68a' : '#f56565',
    text: `Net position: <strong>${fmtSigned(net)}</strong> — ${net >= 0 ? 'you are in surplus this period.' : 'you have a deficit this period.'}`,
  });

  return insights;
}

export function applyFilters(transactions: Transaction[], filters: FilterState): Transaction[] {
  let result = [...transactions];

  if (filters.type !== 'all') {
    result = result.filter(t => t.type === filters.type);
  }
  if (filters.category !== 'all') {
    result = result.filter(t => t.cat === filters.category);
  }
  if (filters.search.trim()) {
    const q = filters.search.toLowerCase();
    result = result.filter(t =>
      t.desc.toLowerCase().includes(q) || t.cat.toLowerCase().includes(q)
    );
  }

  switch (filters.sort) {
    case 'date-desc':   result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); break;
    case 'date-asc':    result.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()); break;
    case 'amount-desc': result.sort((a, b) => b.amount - a.amount); break;
    case 'amount-asc':  result.sort((a, b) => a.amount - b.amount); break;
  }

  return result;
}

export function nextId(transactions: Transaction[]): number {
  return transactions.reduce((m, t) => Math.max(m, t.id), 0) + 1;
}
