import { Transaction, Category } from '../types';

export const MOCK_TRANSACTIONS: Transaction[] = [
  { id: 1,  desc: 'Monthly Salary',       amount: 5500, cat: 'Salary',        type: 'income',  date: '2025-06-01' },
  { id: 2,  desc: 'Rent Payment',          amount: 1800, cat: 'Housing',       type: 'expense', date: '2025-06-02' },
  { id: 3,  desc: 'Grocery Shopping',      amount: 145,  cat: 'Food',          type: 'expense', date: '2025-06-03' },
  { id: 4,  desc: 'Freelance Project',     amount: 1200, cat: 'Freelance',     type: 'income',  date: '2025-06-05' },
  { id: 5,  desc: 'Netflix Subscription',  amount: 18,   cat: 'Entertainment', type: 'expense', date: '2025-06-06' },
  { id: 6,  desc: 'Gym Membership',        amount: 50,   cat: 'Health',        type: 'expense', date: '2025-06-07' },
  { id: 7,  desc: 'Uber Rides',            amount: 62,   cat: 'Transport',     type: 'expense', date: '2025-06-08' },
  { id: 8,  desc: 'Amazon Order',          amount: 89,   cat: 'Shopping',      type: 'expense', date: '2025-06-10' },
  { id: 9,  desc: 'Stock Dividend',        amount: 340,  cat: 'Investment',    type: 'income',  date: '2025-06-12' },
  { id: 10, desc: 'Restaurant Dinner',     amount: 78,   cat: 'Food',          type: 'expense', date: '2025-06-13' },
  { id: 11, desc: 'Electric Bill',         amount: 92,   cat: 'Housing',       type: 'expense', date: '2025-06-14' },
  { id: 12, desc: 'Online Course',         amount: 39,   cat: 'Entertainment', type: 'expense', date: '2025-06-15' },
  { id: 13, desc: 'Doctor Visit',          amount: 120,  cat: 'Health',        type: 'expense', date: '2025-06-16' },
  { id: 14, desc: 'Spotify Premium',       amount: 10,   cat: 'Entertainment', type: 'expense', date: '2025-06-17' },
  { id: 15, desc: 'Coffee & Snacks',       amount: 34,   cat: 'Food',          type: 'expense', date: '2025-06-18' },
  { id: 16, desc: 'Side Project Income',   amount: 800,  cat: 'Freelance',     type: 'income',  date: '2025-06-19' },
  { id: 17, desc: 'Monthly Salary',        amount: 5500, cat: 'Salary',        type: 'income',  date: '2025-05-01' },
  { id: 18, desc: 'Rent Payment',          amount: 1800, cat: 'Housing',       type: 'expense', date: '2025-05-02' },
  { id: 19, desc: 'Grocery Shopping',      amount: 160,  cat: 'Food',          type: 'expense', date: '2025-05-04' },
  { id: 20, desc: 'Car Insurance',         amount: 180,  cat: 'Transport',     type: 'expense', date: '2025-05-05' },
  { id: 21, desc: 'Freelance Project',     amount: 900,  cat: 'Freelance',     type: 'income',  date: '2025-05-10' },
  { id: 22, desc: 'Investment Return',     amount: 420,  cat: 'Investment',    type: 'income',  date: '2025-05-15' },
  { id: 23, desc: 'Electricity Bill',      amount: 85,   cat: 'Housing',       type: 'expense', date: '2025-05-16' },
  { id: 24, desc: 'Movie Tickets',         amount: 45,   cat: 'Entertainment', type: 'expense', date: '2025-05-18' },
  { id: 25, desc: 'Monthly Salary',        amount: 5500, cat: 'Salary',        type: 'income',  date: '2025-04-01' },
  { id: 26, desc: 'Rent Payment',          amount: 1800, cat: 'Housing',       type: 'expense', date: '2025-04-02' },
  { id: 27, desc: 'Grocery Run',           amount: 130,  cat: 'Food',          type: 'expense', date: '2025-04-05' },
  { id: 28, desc: 'New Shoes',             amount: 110,  cat: 'Shopping',      type: 'expense', date: '2025-04-08' },
  { id: 29, desc: 'Consulting Fee',        amount: 1500, cat: 'Freelance',     type: 'income',  date: '2025-04-12' },
  { id: 30, desc: 'Pharmacy',              amount: 65,   cat: 'Health',        type: 'expense', date: '2025-04-20' },
];

export const ALL_CATEGORIES: Category[] = [
  'Salary', 'Freelance', 'Investment',
  'Food', 'Transport', 'Housing',
  'Health', 'Entertainment', 'Shopping', 'Other',
];

export const CATEGORY_COLORS: Record<Category, string> = {
  Food:          '#6ee76e',
  Transport:     '#5b8df6',
  Housing:       '#a78bfa',
  Health:        '#fc8181',
  Entertainment: '#fbbf24',
  Shopping:      '#c4b5fd',
  Salary:        '#22d68a',
  Freelance:     '#67e8f9',
  Investment:    '#d8b4fe',
  Other:         '#9aa3b8',
};

export const CATEGORY_EMOJIS: Record<Category, string> = {
  Salary:        '💰',
  Freelance:     '💻',
  Investment:    '📈',
  Food:          '🍔',
  Transport:     '🚗',
  Housing:       '🏠',
  Health:        '💊',
  Entertainment: '🎬',
  Shopping:      '🛍️',
  Other:         '📦',
};
