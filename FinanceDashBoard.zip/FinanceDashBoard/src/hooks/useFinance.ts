import { useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  getSummary,
  getMonthlyData,
  getCategoryBreakdown,
  getInsights,
  applyFilters,
} from '../utils';

export function useSummary() {
  const { state } = useApp();
  return useMemo(() => getSummary(state.transactions), [state.transactions]);
}

export function useFilteredTransactions() {
  const { state } = useApp();
  return useMemo(
    () => applyFilters(state.transactions, state.filters),
    [state.transactions, state.filters]
  );
}

export function useMonthlyData() {
  const { state } = useApp();
  return useMemo(() => getMonthlyData(state.transactions), [state.transactions]);
}

export function useCategoryBreakdown() {
  const { state } = useApp();
  return useMemo(() => getCategoryBreakdown(state.transactions), [state.transactions]);
}

export function useInsights() {
  const { state } = useApp();
  return useMemo(() => getInsights(state.transactions), [state.transactions]);
}

export function useRecentTransactions(limit = 5) {
  const { state } = useApp();
  return useMemo(
    () =>
      [...state.transactions]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, limit),
    [state.transactions, limit]
  );
}
