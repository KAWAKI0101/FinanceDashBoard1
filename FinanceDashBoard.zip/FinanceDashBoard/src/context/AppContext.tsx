import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Transaction, FilterState, Role, SortOption, Category, TransactionType } from '../types';
import { MOCK_TRANSACTIONS } from '../data/mockData';
import { nextId } from '../utils';

// ─── State ───────────────────────────────────────────────────────────────────
interface AppState {
  transactions: Transaction[];
  filters: FilterState;
  role: Role;
  activePage: string;
}

const initialFilters: FilterState = {
  type: 'all',
  category: 'all',
  search: '',
  sort: 'date-desc',
};

const initialState: AppState = {
  transactions: MOCK_TRANSACTIONS,
  filters: initialFilters,
  role: 'admin',
  activePage: 'dashboard',
};

// ─── Actions ─────────────────────────────────────────────────────────────────
type Action =
  | { type: 'ADD_TRANSACTION';    payload: Omit<Transaction, 'id'> }
  | { type: 'EDIT_TRANSACTION';   payload: Transaction }
  | { type: 'DELETE_TRANSACTION'; payload: number }
  | { type: 'SET_FILTER';         payload: Partial<FilterState> }
  | { type: 'SET_ROLE';           payload: Role }
  | { type: 'SET_PAGE';           payload: string }
  | { type: 'RESET_DATA' };

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'ADD_TRANSACTION':
      return {
        ...state,
        transactions: [
          ...state.transactions,
          { ...action.payload, id: nextId(state.transactions) },
        ],
      };
    case 'EDIT_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.map(t =>
          t.id === action.payload.id ? action.payload : t
        ),
      };
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter(t => t.id !== action.payload),
      };
    case 'SET_FILTER':
      return { ...state, filters: { ...state.filters, ...action.payload } };
    case 'SET_ROLE':
      return { ...state, role: action.payload };
    case 'SET_PAGE':
      return { ...state, filters: initialFilters, activePage: action.payload };
    case 'RESET_DATA':
      return { ...initialState };
    default:
      return state;
  }
}

// ─── Context ─────────────────────────────────────────────────────────────────
interface AppContextValue {
  state: AppState;
  addTransaction:    (tx: Omit<Transaction, 'id'>) => void;
  editTransaction:   (tx: Transaction) => void;
  deleteTransaction: (id: number) => void;
  setFilter:         (f: Partial<FilterState>) => void;
  setRole:           (r: Role) => void;
  setPage:           (p: string) => void;
  resetData:         () => void;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const value: AppContextValue = {
    state,
    addTransaction:    payload => dispatch({ type: 'ADD_TRANSACTION', payload }),
    editTransaction:   payload => dispatch({ type: 'EDIT_TRANSACTION', payload }),
    deleteTransaction: id      => dispatch({ type: 'DELETE_TRANSACTION', payload: id }),
    setFilter:         f       => dispatch({ type: 'SET_FILTER', payload: f }),
    setRole:           r       => dispatch({ type: 'SET_ROLE', payload: r }),
    setPage:           p       => dispatch({ type: 'SET_PAGE', payload: p }),
    resetData:         ()      => dispatch({ type: 'RESET_DATA' }),
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
