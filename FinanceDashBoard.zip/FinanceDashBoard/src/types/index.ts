export type TransactionType = 'income' | 'expense';

export type Category =
  | 'Salary'
  | 'Freelance'
  | 'Investment'
  | 'Food'
  | 'Transport'
  | 'Housing'
  | 'Health'
  | 'Entertainment'
  | 'Shopping'
  | 'Other';

export type Role = 'admin' | 'viewer';

export type SortOption = 'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc';

export interface Transaction {
  id: number;
  desc: string;
  amount: number;
  cat: Category;
  type: TransactionType;
  date: string; // YYYY-MM-DD
}

export interface FilterState {
  type: TransactionType | 'all';
  category: Category | 'all';
  search: string;
  sort: SortOption;
}

export interface Summary {
  income: number;
  expenses: number;
  balance: number;
  savingsRate: number;
}

export interface MonthlyData {
  labels: string[];
  income: number[];
  expenses: number[];
}

export interface CategoryBreakdown {
  category: Category;
  amount: number;
  percentage: number;
}

export interface Insight {
  icon: string;
  color: string;
  text: string;
}
