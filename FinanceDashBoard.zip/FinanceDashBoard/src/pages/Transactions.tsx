import React from 'react';
import TransactionTable from '../components/transactions/TransactionTable';
import styles from './Pages.module.css';

export default function Transactions() {
  return (
    <div className={styles.content}>
      <TransactionTable />
    </div>
  );
}
