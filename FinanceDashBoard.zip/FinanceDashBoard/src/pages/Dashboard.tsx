

import React from 'react';
import SummaryCards from '../components/dashboard/SummaryCards';
import RecentTransactions from '../components/dashboard/RecentTransactions';
import { TrendChart } from '../components/charts/TrendChart';
import SpendingDonut from '../components/charts/SpendingDonut';
import styles from './pages.module.css';


export default function Dashboard() {
  return (
    <div className={styles.content}>
      <SummaryCards />

      <div className={styles.chartsRow}>
        <TrendChart />
        <SpendingDonut />
      </div>

      <RecentTransactions />
    </div>
  );
}
