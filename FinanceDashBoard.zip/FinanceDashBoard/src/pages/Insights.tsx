import React from 'react';
import InsightsPanel from '../components/insights/InsightsPanel';
import styles from './Pages.module.css';

export default function Insights() {
  return (
    <div className={styles.content}>
      <InsightsPanel />
    </div>
  );
}
