import React from 'react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import styles from './Pages.module.css';
import settingsStyles from './Settings.module.css';

export default function Settings() {
  const { state, setRole, resetData } = useApp();

  function handleReset() {
    if (window.confirm('Reset all transactions to original sample data?')) {
      resetData();
    }
  }

  return (
    <div className={styles.content}>
      <div className={settingsStyles.container}>

        {/* Role Management */}
        <section className={settingsStyles.section}>
          <h2 className={settingsStyles.sectionTitle}>Role Management</h2>
          <p className={settingsStyles.sectionDesc}>
            Switch between Admin and Viewer roles to see different UI behaviors.
            This simulates frontend RBAC without a backend.
          </p>

          <div className={settingsStyles.roleGrid}>
            {(['admin', 'viewer'] as Role[]).map(role => (
              <button
                key={role}
                className={`${settingsStyles.roleCard} ${state.role === role ? settingsStyles.roleActive : ''}`}
                onClick={() => setRole(role)}
              >
                <div className={settingsStyles.roleIcon}>
                  {role === 'admin' ? '🔐' : '👁️'}
                </div>
                <div className={settingsStyles.roleName}>
                  {role === 'admin' ? 'Admin' : 'Viewer'}
                </div>
                <div className={settingsStyles.roleDesc}>
                  {role === 'admin'
                    ? 'Full access — can add, edit, and delete transactions'
                    : 'Read-only — can view data but cannot modify'}
                </div>
                {state.role === role && (
                  <div className={settingsStyles.activePill}>Active</div>
                )}
              </button>
            ))}
          </div>
        </section>

        {/* RBAC Reference */}
        <section className={settingsStyles.section}>
          <h2 className={settingsStyles.sectionTitle}>RBAC Behaviour Reference</h2>
          <div className={settingsStyles.table}>
            {[
              ['Feature', 'Admin', 'Viewer'],
              ['View transactions', '✓', '✓'],
              ['Search & filter', '✓', '✓'],
              ['View insights', '✓', '✓'],
              ['Add transaction', '✓', '✗'],
              ['Edit transaction', '✓', '✗'],
              ['Delete transaction', '✓', '✗'],
              ['Switch role', '✓', '✓'],
            ].map(([feature, admin, viewer], i) => (
              <div key={i} className={`${settingsStyles.tableRow} ${i === 0 ? settingsStyles.tableHead : ''}`}>
                <span>{feature}</span>
                <span style={{ color: i === 0 ? 'var(--text3)' : admin === '✓' ? 'var(--green)' : 'var(--red)' }}>{admin}</span>
                <span style={{ color: i === 0 ? 'var(--text3)' : viewer === '✓' ? 'var(--green)' : 'var(--red)' }}>{viewer}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Data Management */}
        <section className={settingsStyles.section}>
          <h2 className={settingsStyles.sectionTitle}>Data Management</h2>
          <p className={settingsStyles.sectionDesc}>
            Reset all transactions back to the original 30 sample records.
          </p>
          <button className={settingsStyles.resetBtn} onClick={handleReset}>
            ↺ Reset to Sample Data
          </button>
        </section>

        {/* About */}
        <section className={settingsStyles.section}>
          <h2 className={settingsStyles.sectionTitle}>About FinTrack</h2>
          <div className={settingsStyles.aboutBox}>
            <div className={settingsStyles.aboutRow}><span>Framework</span><span>React 18 + TypeScript</span></div>
            <div className={settingsStyles.aboutRow}><span>State</span><span>useReducer + Context API</span></div>
            <div className={settingsStyles.aboutRow}><span>Charts</span><span>Chart.js 4</span></div>
            <div className={settingsStyles.aboutRow}><span>Styling</span><span>CSS Modules</span></div>
            <div className={settingsStyles.aboutRow}><span>Data</span><span>Static mock data (30 transactions)</span></div>
            <div className={settingsStyles.aboutRow}><span>RBAC</span><span>Frontend-simulated (Admin / Viewer)</span></div>
          </div>
        </section>

      </div>
    </div>
  );
}
