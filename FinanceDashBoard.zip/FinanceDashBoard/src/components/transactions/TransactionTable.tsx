import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useFilteredTransactions } from '../../hooks/useFinance';
import { Transaction, Category, SortOption, TransactionType } from '../../types';
import { ALL_CATEGORIES, CATEGORY_EMOJIS } from '../../data/mockData';
import { fmt, formatDate } from '../../utils';
import TransactionModal from '../modals/TransactionModal';
import styles from './TransactionTable.module.css';

const CAT_CLASS: Record<Category, string> = {
  Food:          styles.catFood,
  Transport:     styles.catTransport,
  Housing:       styles.catHousing,
  Health:        styles.catHealth,
  Entertainment: styles.catEntertainment,
  Shopping:      styles.catShopping,
  Salary:        styles.catSalary,
  Freelance:     styles.catFreelance,
  Investment:    styles.catInvestment,
  Other:         styles.catOther,
};

export default function TransactionTable() {
  const { state, setFilter, deleteTransaction } = useApp();
  const filtered = useFilteredTransactions();
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [showModal, setShowModal] = useState(false);
  const isAdmin = state.role === 'admin';

  function handleDelete(id: number) {
    if (window.confirm('Delete this transaction?')) deleteTransaction(id);
  }

  return (
    <div className={styles.card}>
      {/* Toolbar */}
      <div className={styles.toolbar}>
        {(['all', 'income', 'expense'] as const).map(f => (
          <button
            key={f}
            className={`${styles.filterBtn} ${state.filters.type === f ? styles.active : ''}`}
            onClick={() => setFilter({ type: f as TransactionType | 'all' })}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}

        <select
          className={styles.select}
          value={state.filters.sort}
          onChange={e => setFilter({ sort: e.target.value as SortOption })}
        >
          <option value="date-desc">Date (Newest)</option>
          <option value="date-asc">Date (Oldest)</option>
          <option value="amount-desc">Amount (High)</option>
          <option value="amount-asc">Amount (Low)</option>
        </select>

        <select
          className={styles.select}
          value={state.filters.category}
          onChange={e => setFilter({ category: e.target.value as Category | 'all' })}
        >
          <option value="all">All Categories</option>
          {ALL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>

        {isAdmin && (
          <button
            className={styles.addBtn}
            onClick={() => { setEditingTx(null); setShowModal(true); }}
          >
            + Add
          </button>
        )}
      </div>

      {filtered.length === 0 ? (
        <div className={styles.empty}>
          <div className={styles.emptyIcon}>⊘</div>
          <div className={styles.emptyTitle}>No transactions found</div>
          <div className={styles.emptySub}>Try adjusting your filters or search</div>
        </div>
      ) : (
        <>
          {/* Desktop table */}
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Transaction</th>
                  <th>Category</th>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Amount</th>
                  {isAdmin && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map(tx => (
                  <tr key={tx.id}>
                    <td>
                      <div className={styles.txInfo}>
                        <div className={styles.txAvatar}>{CATEGORY_EMOJIS[tx.cat]}</div>
                        <span className={styles.txDesc}>{tx.desc}</span>
                      </div>
                    </td>
                    <td>
                      <span className={`${styles.catPill} ${CAT_CLASS[tx.cat]}`}>{tx.cat}</span>
                    </td>
                    <td className={styles.dateCell}>{formatDate(tx.date)}</td>
                    <td>
                      <span className={`${styles.typeBadge} ${tx.type === 'income' ? styles.income : styles.expense}`}>
                        {tx.type}
                      </span>
                    </td>
                    <td className={`${styles.amount} ${tx.type === 'income' ? styles.amountIncome : styles.amountExpense}`}>
                      {tx.type === 'income' ? '+' : '−'}{fmt(tx.amount)}
                    </td>
                    {isAdmin && (
                      <td>
                        <div className={styles.actions}>
                          <button className={styles.btnEdit} onClick={() => { setEditingTx(tx); setShowModal(true); }}>Edit</button>
                          <button className={styles.btnDel}  onClick={() => handleDelete(tx.id)}>Del</button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile card list */}
          <div className={styles.cardList}>
            {filtered.map(tx => (
              <div key={tx.id} className={styles.mobileCard}>
                <div className={styles.mobileLeft}>
                  <div className={styles.txAvatar}>{CATEGORY_EMOJIS[tx.cat]}</div>
                  <div className={styles.mobileInfo}>
                    <div className={styles.mobileDesc}>{tx.desc}</div>
                    <div className={styles.mobileMeta}>
                      <span className={`${styles.catPill} ${CAT_CLASS[tx.cat]}`}>{tx.cat}</span>
                      <span className={styles.mobileDate}>{formatDate(tx.date)}</span>
                    </div>
                  </div>
                </div>
                <div className={styles.mobileRight}>
                  <span className={`${styles.mobileAmount} ${tx.type === 'income' ? styles.amountIncome : styles.amountExpense}`}>
                    {tx.type === 'income' ? '+' : '−'}{fmt(tx.amount)}
                  </span>
                  {isAdmin && (
                    <div className={styles.mobileActions}>
                      <button className={styles.btnEdit} onClick={() => { setEditingTx(tx); setShowModal(true); }}>Edit</button>
                      <button className={styles.btnDel}  onClick={() => handleDelete(tx.id)}>Del</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {showModal && (
        <TransactionModal
          transaction={editingTx}
          onClose={() => setShowModal(false)}
        />
      )}
    </div>
  );
}
