import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Transaction, Category, TransactionType } from '../../types';
import { ALL_CATEGORIES } from '../../data/mockData';
import styles from './TransactionModal.module.css';

interface Props {
  transaction: Transaction | null;
  onClose: () => void;
}

const today = new Date().toISOString().split('T')[0];

const EMPTY_FORM = {
  desc:   '',
  amount: '',
  cat:    'Food' as Category,
  type:   'expense' as TransactionType,
  date:   today,
};

export default function TransactionModal({ transaction, onClose }: Props) {
  const { addTransaction, editTransaction } = useApp();
  const isEdit = transaction !== null;

  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof typeof EMPTY_FORM, string>>>({});

  useEffect(() => {
    if (transaction) {
      setForm({
        desc:   transaction.desc,
        amount: String(transaction.amount),
        cat:    transaction.cat,
        type:   transaction.type,
        date:   transaction.date,
      });
    } else {
      setForm(EMPTY_FORM);
    }
    setErrors({});
  }, [transaction]);

  function validate() {
    const e: typeof errors = {};
    if (!form.desc.trim())              e.desc   = 'Description is required';
    if (!form.amount || isNaN(Number(form.amount)) || Number(form.amount) <= 0)
                                        e.amount = 'Enter a valid positive amount';
    if (!form.date)                     e.date   = 'Date is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleSubmit() {
    if (!validate()) return;
    const payload = {
      desc:   form.desc.trim(),
      amount: parseFloat(form.amount),
      cat:    form.cat,
      type:   form.type,
      date:   form.date,
    };
    if (isEdit && transaction) {
      editTransaction({ ...payload, id: transaction.id });
    } else {
      addTransaction(payload);
    }
    onClose();
  }

  function set(field: keyof typeof EMPTY_FORM, value: string) {
    setForm(f => ({ ...f, [field]: value }));
    setErrors(e => ({ ...e, [field]: undefined }));
  }

  return (
    <div className={styles.overlay} onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={styles.modal} role="dialog" aria-modal="true" aria-label={isEdit ? 'Edit Transaction' : 'Add Transaction'}>
        <div className={styles.header}>
          <h2 className={styles.title}>{isEdit ? 'Edit Transaction' : 'Add Transaction'}</h2>
          <button className={styles.closeBtn} onClick={onClose} aria-label="Close">✕</button>
        </div>

        <div className={styles.body}>
          {/* Description */}
          <div className={styles.formGroup}>
            <label className={styles.label}>Description</label>
            <input
              className={`${styles.input} ${errors.desc ? styles.inputError : ''}`}
              placeholder="e.g. Grocery Shopping"
              value={form.desc}
              onChange={e => set('desc', e.target.value)}
            />
            {errors.desc && <span className={styles.error}>{errors.desc}</span>}
          </div>

          {/* Amount */}
          <div className={styles.formGroup}>
            <label className={styles.label}>Amount ($)</label>
            <input
              className={`${styles.input} ${errors.amount ? styles.inputError : ''}`}
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={form.amount}
              onChange={e => set('amount', e.target.value)}
            />
            {errors.amount && <span className={styles.error}>{errors.amount}</span>}
          </div>

          {/* Category + Type row */}
          <div className={styles.row}>
            <div className={styles.formGroup}>
              <label className={styles.label}>Category</label>
              <select
                className={styles.input}
                value={form.cat}
                onChange={e => set('cat', e.target.value)}
              >
                {ALL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div className={styles.formGroup}>
              <label className={styles.label}>Type</label>
              <select
                className={styles.input}
                value={form.type}
                onChange={e => set('type', e.target.value)}
              >
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
            </div>
          </div>

          {/* Date */}
          <div className={styles.formGroup}>
            <label className={styles.label}>Date</label>
            <input
              className={`${styles.input} ${errors.date ? styles.inputError : ''}`}
              type="date"
              value={form.date}
              onChange={e => set('date', e.target.value)}
            />
            {errors.date && <span className={styles.error}>{errors.date}</span>}
          </div>
        </div>

        <div className={styles.footer}>
          <button className={styles.btnCancel} onClick={onClose}>Cancel</button>
          <button className={styles.btnSave} onClick={handleSubmit}>
            {isEdit ? 'Save Changes' : 'Add Transaction'}
          </button>
        </div>
      </div>
    </div>
  );
}
