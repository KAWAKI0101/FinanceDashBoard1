import React from 'react';
import { useApp } from '../../context/AppContext';
import styles from './Topbar.module.css';

const PAGE_TITLES: Record<string, string> = {
  dashboard:    'Dashboard',
  transactions: 'Transactions',
  insights:     'Insights',
  settings:     'Settings',
};

interface TopbarProps {
  onMenuClick: () => void;
}

export default function Topbar({ onMenuClick }: TopbarProps) {
  const { state, setFilter } = useApp();

  return (
    <header className={styles.topbar}>
      <div className={styles.left}>
        <button
          className={styles.menuBtn}
          onClick={onMenuClick}
          aria-label="Open menu"
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>
        <h1 className={styles.title}>{PAGE_TITLES[state.activePage] ?? 'FinTrack'}</h1>
      </div>

      <div className={styles.right}>
        <input
          className={styles.search}
          placeholder="Search transactions…"
          value={state.filters.search}
          onChange={e => setFilter({ search: e.target.value })}
          aria-label="Search transactions"
        />
        <span className={`${styles.badge} ${state.role === 'admin' ? styles.badgeAdmin : styles.badgeViewer}`}>
          {state.role === 'admin' ? 'Admin' : 'Viewer'}
        </span>
      </div>
    </header>
  );
}
