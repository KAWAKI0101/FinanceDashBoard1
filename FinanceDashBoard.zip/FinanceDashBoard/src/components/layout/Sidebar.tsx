import React from 'react';
import { useApp } from '../../context/AppContext';
import { Role } from '../../types';
import styles from './Sidebar.module.css';

const NAV_ITEMS = [
  { id: 'dashboard',    icon: '▣', label: 'Dashboard'    },
  { id: 'transactions', icon: '⇄', label: 'Transactions' },
  { id: 'insights',     icon: '◎', label: 'Insights'     },
  { id: 'settings',     icon: '⚙', label: 'Settings'     },
];

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const { state, setPage, setRole } = useApp();

  const handleNav = (id: string) => {
    setPage(id);
    onClose();
  };

  return (
    <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
      <div className={styles.header}>
        <div className={styles.logo}>
          Fin<span className={styles.logoAccent}>Track</span>
        </div>
        <button className={styles.closeBtn} onClick={onClose} aria-label="Close menu">✕</button>
      </div>

      <nav className={styles.nav}>
        <div className={styles.navSection}>Main</div>
        {NAV_ITEMS.slice(0, 3).map(item => (
          <button
            key={item.id}
            className={`${styles.navItem} ${state.activePage === item.id ? styles.active : ''}`}
            onClick={() => handleNav(item.id)}
          >
            <span className={styles.navIcon}>{item.icon}</span>
            {item.label}
          </button>
        ))}

        <div className={styles.navSection}>Account</div>
        {NAV_ITEMS.slice(3).map(item => (
          <button
            key={item.id}
            className={`${styles.navItem} ${state.activePage === item.id ? styles.active : ''}`}
            onClick={() => handleNav(item.id)}
          >
            <span className={styles.navIcon}>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      <div className={styles.roleBox}>
        <div className={styles.roleLabel}>Active Role</div>
        <select
          className={styles.roleSelect}
          value={state.role}
          onChange={e => setRole(e.target.value as Role)}
        >
          <option value="admin">Admin</option>
          <option value="viewer">Viewer</option>
        </select>
      </div>
    </aside>
  );
}
