import React from 'react';
import { useApp } from '../../context/AppContext';
import styles from './BottomNav.module.css';

const NAV_ITEMS = [
  { id: 'dashboard',    icon: '▣', label: 'Home'    },
  { id: 'transactions', icon: '⇄', label: 'Txns'   },
  { id: 'insights',     icon: '◎', label: 'Insights'},
  { id: 'settings',     icon: '⚙', label: 'Settings'},
];

export default function BottomNav() {
  const { state, setPage } = useApp();

  return (
    <nav className={styles.bottomNav}>
      {NAV_ITEMS.map(item => (
        <button
          key={item.id}
          className={`${styles.navItem} ${state.activePage === item.id ? styles.active : ''}`}
          onClick={() => setPage(item.id)}
        >
          <span className={styles.icon}>{item.icon}</span>
          <span className={styles.label}>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
