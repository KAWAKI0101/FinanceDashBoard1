import React from 'react';
import { useSummary } from '../../hooks/useFinance';
import { fmt } from '../../utils';
import styles from './SummaryCards.module.css';

interface CardProps {
  label: string;
  value: string;
  change: string;
  icon: string;
  variant: 'blue' | 'green' | 'red' | 'amber';
}

function Card({ label, value, change, icon, variant }: CardProps) {
  return (
    <div className={`${styles.card} ${styles[variant]}`}>
      <div className={styles.icon}>{icon}</div>
      <div className={styles.label}>{label}</div>
      <div className={styles.value}>{value}</div>
      <div className={styles.change}>{change}</div>
    </div>
  );
}

export default function SummaryCards() {
  const { income, expenses, balance, savingsRate } = useSummary();

  return (
    <div className={styles.grid}>
      <Card
        label="TOTAL BALANCE"
        value={fmt(balance)}
        change={balance >= 0 ? '▲ Positive net' : '▼ Negative net'}
        icon="◈"
        variant="blue"
      />
      <Card
        label="TOTAL INCOME"
        value={fmt(income)}
        change="All income sources"
        icon="↑"
        variant="green"
      />
      <Card
        label="TOTAL EXPENSES"
        value={fmt(expenses)}
        change="All expense categories"
        icon="↓"
        variant="red"
      />
      <Card
        label="SAVINGS RATE"
        value={`${savingsRate}%`}
        change="of income saved"
        icon="◆"
        variant="amber"
      />
    </div>
  );
}
