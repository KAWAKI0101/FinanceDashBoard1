import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useRecentTransactions } from '../../hooks/useFinance';
import { CATEGORY_EMOJIS } from '../../data/mockData';
import { fmt, formatDateShort } from '../../utils';
import TransactionModal from '../modals/TransactionModal';
import { Transaction } from '../../types';
import styles from './RecentTransactions.module.css';

export default function RecentTransactions() {
  const { setPage } = useApp();
  const recent = useRecentTransactions(6);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div className={styles.title}>Recent Transactions</div>
        <button className={styles.viewAll} onClick={() => setPage('transactions')}>
          View All →
        </button>
      </div>

      {recent.length === 0 ? (
        <div className={styles.empty}>No transactions yet</div>
      ) : (
        <table className={styles.table}>
          <tbody>
            {recent.map(tx => (
              <tr key={tx.id} className={styles.row}>
                <td className={styles.tdInfo}>
                  <div className={styles.avatar}>{CATEGORY_EMOJIS[tx.cat]}</div>
                  <div>
                    <div className={styles.desc}>{tx.desc}</div>
                    <div className={styles.cat}>{tx.cat}</div>
                  </div>
                </td>
                <td className={styles.tdDate}>{formatDateShort(tx.date)}</td>
                <td>
                  <span className={`${styles.badge} ${tx.type === 'income' ? styles.income : styles.expense}`}>
                    {tx.type}
                  </span>
                </td>
                <td className={`${styles.amount} ${tx.type === 'income' ? styles.amtIncome : styles.amtExpense}`}>
                  {tx.type === 'income' ? '+' : '−'}{fmt(tx.amount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {editingTx && (
        <TransactionModal transaction={editingTx} onClose={() => setEditingTx(null)} />
      )}
    </div>
  );
}
