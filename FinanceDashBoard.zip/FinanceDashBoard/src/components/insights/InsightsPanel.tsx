import React from 'react';
import { useCategoryBreakdown, useInsights, useSummary } from '../../hooks/useFinance';
import { CATEGORY_COLORS } from '../../data/mockData';
import { fmt, fmtSigned } from '../../utils';
import MonthlyBarChart from '../charts/MonthlyBarChart';
import styles from './InsightsPanel.module.css';

export default function InsightsPanel() {
  const { income, expenses, balance, savingsRate } = useSummary();
  const breakdown = useCategoryBreakdown();
  const insights  = useInsights();
  const net       = income - expenses;
  const topCat    = breakdown[0];
  const avgTx     = breakdown.length > 0
    ? breakdown.reduce((s, b) => s + b.amount, 0) / breakdown.length
    : 0;

  return (
    <div className={styles.wrapper}>
      {/* KPI row */}
      <div className={styles.kpiRow}>
        <div className={styles.kpiCard}>
          <div className={styles.kpiLabel}>Top Spending Category</div>
          <div className={styles.kpiValue} style={{ color: topCat ? CATEGORY_COLORS[topCat.category] : 'var(--text)' }}>
            {topCat ? `${topCat.category}` : '—'}
          </div>
          <div className={styles.kpiSub}>
            {topCat ? `${fmt(topCat.amount)} · ${topCat.percentage}% of expenses` : 'No expenses yet'}
          </div>
        </div>

        <div className={styles.kpiCard}>
          <div className={styles.kpiLabel}>Monthly Net</div>
          <div className={styles.kpiValue} style={{ color: net >= 0 ? 'var(--green)' : 'var(--red)' }}>
            {fmtSigned(net)}
          </div>
          <div className={styles.kpiSub}>{net >= 0 ? 'Surplus this period' : 'Deficit this period'}</div>
        </div>

        <div className={styles.kpiCard}>
          <div className={styles.kpiLabel}>Savings Rate</div>
          <div className={styles.kpiValue} style={{ color: savingsRate >= 20 ? 'var(--green)' : 'var(--amber)' }}>
            {savingsRate}%
          </div>
          <div className={styles.kpiSub}>{savingsRate >= 20 ? 'On track — great work!' : 'Below 20% target'}</div>
        </div>

        <div className={styles.kpiCard}>
          <div className={styles.kpiLabel}>Avg Category Spend</div>
          <div className={styles.kpiValue} style={{ color: 'var(--purple)' }}>
            {fmt(avgTx)}
          </div>
          <div className={styles.kpiSub}>per spending category</div>
        </div>
      </div>

      {/* Monthly bar chart */}
      <MonthlyBarChart />

      {/* Category breakdown + Observations */}
      <div className={styles.bottomRow}>
        {/* Category breakdown */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>Expense by Category</div>
          {breakdown.length === 0 ? (
            <div className={styles.emptyMsg}>No expense data available</div>
          ) : (
            <div className={styles.catList}>
              {breakdown.map(b => (
                <div key={b.category} className={styles.catRow}>
                  <div className={styles.catMeta}>
                    <span className={styles.catName}>{b.category}</span>
                    <span className={styles.catAmt} style={{ color: CATEGORY_COLORS[b.category] }}>
                      {fmt(b.amount)}
                    </span>
                  </div>
                  <div className={styles.progressBar}>
                    <div
                      className={styles.progressFill}
                      style={{
                        width: `${b.percentage}%`,
                        background: CATEGORY_COLORS[b.category],
                      }}
                    />
                  </div>
                  <span className={styles.catPct}>{b.percentage}%</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Observations */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>Key Observations</div>
          <div className={styles.obsList}>
            {insights.map((obs, i) => (
              <div key={i} className={styles.obsItem}>
                <span className={styles.obsIcon} style={{ color: obs.color }}>{obs.icon}</span>
                <p
                  className={styles.obsText}
                  dangerouslySetInnerHTML={{ __html: obs.text }}
                />
              </div>
            ))}
          </div>

          {/* Income vs Expense mini summary */}
          <div className={styles.miniSummary}>
            <div className={styles.miniRow}>
              <span className={styles.miniLabel}>Total Income</span>
              <span className={styles.miniVal} style={{ color: 'var(--green)' }}>{fmt(income)}</span>
            </div>
            <div className={styles.miniRow}>
              <span className={styles.miniLabel}>Total Expenses</span>
              <span className={styles.miniVal} style={{ color: 'var(--red)' }}>{fmt(expenses)}</span>
            </div>
            <div className={styles.miniDivider} />
            <div className={styles.miniRow}>
              <span className={styles.miniLabel}>Net Balance</span>
              <span className={styles.miniVal} style={{ color: net >= 0 ? 'var(--green)' : 'var(--red)', fontWeight: 700 }}>
                {fmtSigned(net)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
