import React, { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { useMonthlyData } from '../../hooks/useFinance';
import styles from './Charts.module.css';

Chart.register(...registerables);

const TOOLTIP_OPTS = {
  backgroundColor: '#1e2330',
  borderColor: '#3a4060',
  borderWidth: 1,
  titleColor: '#e8eaf0',
  bodyColor: '#9aa3b8',
  callbacks: {
    label: (ctx: any) => `${ctx.dataset.label}: $${ctx.parsed.y.toLocaleString()}`,
  },
};

export function TrendChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef  = useRef<Chart | null>(null);
  const data = useMonthlyData();

  useEffect(() => {
    if (!canvasRef.current) return;
    chartRef.current?.destroy();
    chartRef.current = new Chart(canvasRef.current, {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [
          {
            label: 'Income',
            data: data.income,
            borderColor: '#5b8df6',
            backgroundColor: 'rgba(91,141,246,0.10)',
            tension: 0.4,
            fill: true,
            pointRadius: 4,
            pointBackgroundColor: '#5b8df6',
          },
          {
            label: 'Expenses',
            data: data.expenses,
            borderColor: '#f56565',
            backgroundColor: 'rgba(245,101,101,0.08)',
            tension: 0.4,
            fill: true,
            pointRadius: 4,
            pointBackgroundColor: '#f56565',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend:  { display: false },
          tooltip: { ...TOOLTIP_OPTS },
        },
        scales: {
          x: {
            grid:  { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#6b7492', font: { size: 11 } },
          },
          y: {
            grid:  { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#6b7492', font: { size: 11 }, callback: (v: any) => '$' + Number(v).toLocaleString() },
          },
        },
      },
    });
    return () => chartRef.current?.destroy();
  }, [data]);

  return (
    <div className={styles.chartCard}>
      <div className={styles.cardHead}>
        <div>
          <div className={styles.cardTitle}>Balance Trend</div>
          <div className={styles.cardSub}>Last {data.labels.length} months</div>
        </div>
        <div className={styles.legend}>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: '#5b8df6' }} />Income</span>
          <span className={styles.legendItem}><span className={styles.dot} style={{ background: '#f56565' }} />Expenses</span>
        </div>
      </div>
      <div className={styles.chartWrap}>
        <canvas ref={canvasRef} />
      </div>
    </div>
  );
}


