import React, { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { useCategoryBreakdown } from '../../hooks/useFinance';
import { CATEGORY_COLORS } from '../../data/mockData';
import { fmt } from '../../utils';
import styles from './Charts.module.css';

Chart.register(...registerables);

export default function SpendingDonut() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef  = useRef<Chart | null>(null);
  const breakdown = useCategoryBreakdown();

  const labels = breakdown.map(b => b.category);
  const values = breakdown.map(b => b.amount);
  const colors = labels.map(l => CATEGORY_COLORS[l as keyof typeof CATEGORY_COLORS] || '#888');
  const total  = values.reduce((s, v) => s + v, 0);

  useEffect(() => {
    if (!canvasRef.current || breakdown.length === 0) return;
    chartRef.current?.destroy();
    chartRef.current = new Chart(canvasRef.current, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: colors,
          borderColor: '#181c25',
          borderWidth: 2,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1e2330',
            borderColor: '#3a4060',
            borderWidth: 1,
            titleColor: '#e8eaf0',
            bodyColor: '#9aa3b8',
            callbacks: {
              label: (ctx: any) =>
                `${ctx.label}: $${ctx.parsed.toLocaleString()} (${Math.round((ctx.parsed / total) * 100)}%)`,
            },
          },
        },
      },
    });
    return () => chartRef.current?.destroy();
  }, [breakdown]);

  return (
    <div className={styles.chartCard}>
      <div className={styles.cardHead}>
        <div>
          <div className={styles.cardTitle}>Spending Breakdown</div>
          <div className={styles.cardSub}>Total: {fmt(total)}</div>
        </div>
      </div>
      <div className={styles.donutWrap}>
        {breakdown.length === 0 ? (
          <div className={styles.empty}>No expense data</div>
        ) : (
          <canvas ref={canvasRef} />
        )}
      </div>
      <div className={styles.donutLegend}>
        {breakdown.slice(0, 6).map((b, i) => (
          <span key={b.category} className={styles.legendItem}>
            <span className={styles.dot} style={{ background: colors[i] }} />
            {b.category} {b.percentage}%
          </span>
        ))}
      </div>
    </div>
  );
}
